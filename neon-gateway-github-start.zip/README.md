# Neon Getaway

A browser game published from the original HTML file.

## Run locally
Open `index.html` in a modern browser. The game loads Three.js and related scripts from CDNs, so an internet connection is needed.

## Publish with GitHub Pages
1. Create a new GitHub repository named `neon-getaway` (Public is simplest for GitHub Pages).
2. Upload `index.html` and this `README.md` to the repository root.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait a minute or two. GitHub will show the published site URL in the Pages section.

## Notes
- The HTML file is the game itself; it has been renamed to `index.html` so GitHub Pages serves it as the homepage.
- The game uses Three.js and post-processing scripts from public CDNs, so those scripts need internet access.
- This publishes a playable web game. Google Play Android packaging is a separate next step (for example, with Capacitor or a Trusted Web Activity).
